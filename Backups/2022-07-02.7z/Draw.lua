Draw = {
	background = "#303030",
	backgrounda = "#303030FF",
	timer = {
		x = 900,
		active = true,
		font_size = 70,
		font = "Calibri",
		style = "a",
		color = "#FFFFFF",
		stopped_color = "#AAFFAA"
	},
	cstick = {
		x = 1680,
		y = 795,
		size = 150,
		circle = {
			thickness = 2,
			color = "#AAAAAA"
		},
		axis = {
			color = "#AAAAAA"
		},
		border = {
			thickness = 3,
			color = "#FFFFFFFF"
		},
		stick = {
			thickness = 3,
			color = "#FFAAAAFF"
		},
		ball = {
			radius = 5,
			color = "#3333FFFF"
		},
		display = {
			x_offset = 85,
			y_offset = -27,
			distance = 30,
			font_size = 24,
			font = "Courier New",
			style = "ba",
			text_color = "#FF3333",
		}
	},
	buttons = {
		border = "#FFFFFFFF",
		text_color = "#FFFFFF",
		thickness = 4
	},
	a = {
		x = 1750,
		y = 650,
		radius = 30,
		color = "#FF7777FF",
		font_size = 32,
		font = "Calibri",
		style = "a",
		x_offset = -11,
		y_offset = -27
	},
	b = {
		x = 1680,
		y = 650,
		radius = 30,
		color = "#00C000FF",
		font_size = 32,
		font = "Calibri",
		style = "a",
		x_offset = -11,
		y_offset = -27
	},
	s = {
		x = 1715,
		y = 590,
		radius = 30,
		color = "#4444FFFF",
		font_size = 32,
		font = "Calibri",
		style = "a",
		x_offset = -9,
		y_offset = -27
	},
	z = {
		x = 1600,
		y = 630,
		w = 50,
		h = 100,
		color = "#888888FF",
		font_size = 32,
		font = "Calibri",
		style = "a",
		x_offset = -11,
		y_offset = -27
	},
	cbuttons = {
		x = 1620,
		y = 500,
		radius = 20,
		color = "#00FFFFFF",
		offset = 40,
		text_color = "#FFFFFF",
		font_size = 32,
		font = "Calibri",
		style = "a",
		text_offset = {-12, -26},
		triangle_thickness = 5,
		triangle_size = 12,
		up_offset = {0, 0},
		right_offset = {0, 0},
		down_offset = {0, 0},
		left_offset = {0, 0}
	},
	r = {
		x = 1750,
		y = 500,
		w = 100,
		h = 50,
		color = "#888888FF",
		font_size = 32,
		font = "Calibri",
		style = "a",
		x_offset = -11,
		y_offset = -27
	},
	apress = {
		x = 50,
		font_size = 70,
		font = "Calibri",
		style = "a",
		text_color = "#FFFFFF",
		height = 100,
		offset = 100
	},
	slots = {
		x = 1540,
		start_y = 260,
		y_offset = 40,
		x_offset = 140,
		font_size = 24,
		font = "Calibri",
		style = "a",
		text_color = "#FFFFFF",
	}
}

function Draw.main()
	-- Clear the screen
	wgui.fillrecta(Screen.init_width, 0, Screen.extra_width, Screen.height, Draw.backgrounda)
	-- Draw timer
	wgui.setfont(Draw.timer.font_size, Draw.timer.font, Draw.timer.style)
	if Draw.timer.active then
		wgui.setcolor(Draw.timer.color)
	else
		wgui.setcolor(Draw.timer.stopped_color)
	end
	wgui.drawtext(Draw.calc_timer(), {l = Screen.init_width, t = Draw.timer.x, w = Screen.extra_width, h = 100}, "c")
	-- Draw c stick
	Draw.circle(Draw.cstick.x, Draw.cstick.y, Draw.cstick.size / 2, Draw.cstick.circle.thickness, Draw.background, Draw.cstick.circle.color)
	-- Draw axes
	wgui.setpen(Draw.cstick.axis.color)
	wgui.line(Draw.cstick.x - (Draw.cstick.size / 2), Draw.cstick.y, Draw.cstick.x + (Draw.cstick.size / 2), Draw.cstick.y)
	wgui.line(Draw.cstick.x, Draw.cstick.y - (Draw.cstick.size / 2), Draw.cstick.x, Draw.cstick.y + (Draw.cstick.size / 2))
	-- Draw border
	Draw.border(Draw.cstick.x, Draw.cstick.y, Draw.cstick.size, Draw.cstick.size, Draw.cstick.border.thickness, Draw.cstick.border.color)
	-- Draw stick
	wgui.fillpolygona(Draw.calc_stick_points(), Draw.cstick.stick.color)
	Draw.fillcircle(Draw.cstick.x, Draw.cstick.y, Draw.cstick.stick.thickness, Draw.cstick.stick.color)
	-- Draw ball
	Draw.fillcircle(Draw.cstick.x + (Joypad.X * 75 / 128), Draw.cstick.y - (Joypad.Y * 75 / 128), Draw.cstick.ball.radius, Draw.cstick.ball.color)
	-- Draw c stick display
	wgui.setfont(Draw.cstick.display.font_size, Draw.cstick.display.font, Draw.cstick.display.style)
	wgui.setcolor(Draw.cstick.display.text_color)
	wgui.drawtext(string.format("X: %d", Joypad.X), {l = Draw.cstick.x + Draw.cstick.display.x_offset, t = Draw.cstick.y + Draw.cstick.display.y_offset, w = 200, h = 30}, "l")
	wgui.drawtext(string.format("Y: %d", Joypad.Y), {l = Draw.cstick.x + Draw.cstick.display.x_offset, t = Draw.cstick.y + Draw.cstick.display.y_offset + Draw.cstick.display.distance, w = 200, h = 30}, "l")
	-- Draw buttons
	Draw.button("a", "A", "A", 0) -- table name, joypad name, text, type
	Draw.button("b", "B", "B", 0)
	Draw.button("s", "start", "S", 0)
	Draw.button("z", "Z", "Z", 1)
	Draw.button("r", "R", "R", 1)
	-- Draw c buttons
	Draw.set_text("cbuttons")
	wgui.drawtext("C", {l = Draw.cbuttons.x + Draw.cbuttons.text_offset[1], t = Draw.cbuttons.y + Draw.cbuttons.text_offset[2], w = 200, h = 100}, "l")
	Draw.cbutton("Cup", {0, -1}, 0) -- joypad name, table with multipliers for the x and y offsets, angle
	Draw.cbutton("Cright", {1, 0}, -math.pi / 2) -- table example: {0, 0} means no offset, {1, 0} means x offset, {0, -1} means negative y offset
	Draw.cbutton("Cdown", {0, 1}, math.pi)
	Draw.cbutton("Cleft", {-1, 0}, math.pi / 2)
	-- Draw a press counter
	Draw.set_text("apress")
	wgui.drawtext("A Presses:", {l = Screen.init_width, t = Draw.apress.x, w = Screen.extra_width, h = 100}, "c")
	wgui.drawtext(string.format("%d", a_presses), {l = Screen.init_width, t = Draw.apress.x + Draw.apress.offset, w = Screen.extra_width, h = 100}, "c")
	-- Draw variable slots and segment counter
	Draw.set_text("slots")
	wgui.drawtext("Segment", {l = Draw.slots.x, t = Draw.slots.start_y, w = Draw.slots.x_offset, h = 100}, "l")
	wgui.drawtext(string.format("%d", segments), {l = Draw.slots.x + Draw.slots.x_offset, t = Draw.slots.start_y, w = 400, h = 100}, "l")
	for i = 1, 3, 1 do
		if Slots[i].occupied then
			Draw.slot(i)
		end
	end
end

-- Shape drawing functions

function Draw.border(x, y, w, h, b, color) -- Draws a border using 4 rectangles (doesn't overwrite middle)
	wgui.fillrecta(x - (w / 2), y - (h / 2), b, h, color)
	wgui.fillrecta(x - (w / 2) + b, y + (h / 2) - b, w - (b * 2), b, color)
	wgui.fillrecta(x + (w / 2) - b, y - (h / 2), b, h, color)
	wgui.fillrecta(x - (w / 2) + b, y - (h / 2), w - (b * 2), b, color)
end

function Draw.border2(x, y, w, h, thickness, inner_color, border_color) -- Draws a border using 2 overlapping rectangles (overwrites middle)
	wgui.fillrecta(x - (w / 2), y - (h / 2), w, h, border_color)
	wgui.fillrecta(x - (w / 2) + thickness, y - (h / 2) + thickness, w - (thickness * 2), h - (thickness * 2), inner_color)
end

function Draw.circle(x, y, r, thickness, inner_color, border_color) -- Draws a circle border (overwrites middle)
	wgui.fillellipsea(x - r, y - r, r * 2, r * 2, border_color)
	wgui.fillellipsea(x - (r - thickness), y - (r - thickness), (r - thickness) * 2, (r - thickness) * 2, inner_color)
end

function Draw.fillcircle(x, y, r, color) -- Draws a filled in circle
	wgui.fillellipsea(x - r, y - r, r * 2, r * 2, color)
end

function Draw.triangle(x, y, length, angle, thickness, inner_color, border_color)
	wgui.fillpolygona({{
		round(x + (math.cos((math.pi / 2) + angle) * length)),
		round(y - (math.sin((math.pi / 2) + angle) * length))
	}, {
		round(x + (math.cos((7 / 6 * math.pi) + angle) * length)),
		round(y - (math.sin((7 / 6 * math.pi) + angle) * length))
	}, {
		round(x + (math.cos((11 / 6 * math.pi) + angle) * length)),
		round(y - (math.sin((11 / 6 * math.pi) + angle) * length))
	}}, border_color)
	wgui.fillpolygona({{
		round(x + (math.cos((math.pi / 2) + angle) * (length - thickness))),
		round(y - (math.sin((math.pi / 2) + angle) * (length - thickness)))
	}, {
		round(x + (math.cos((7 / 6 * math.pi) + angle) * (length - thickness))),
		round(y - (math.sin((7 / 6 * math.pi) + angle) * (length - thickness)))
	}, {
		round(x + (math.cos((11 / 6 * math.pi) + angle) * (length - thickness))),
		round(y - (math.sin((11 / 6 * math.pi) + angle) * (length - thickness)))
	}}, inner_color)
end

-- Complex drawing functions

function Draw.button(button, button_name, text, ty) -- Draws a circular button and text
	if ty == 0 then -- circle
		if Joypad[button_name] then
			Draw.circle(Draw[button].x, Draw[button].y, Draw[button].radius, Draw.buttons.thickness, Draw[button].color, Draw.buttons.border)
		else
			Draw.circle(Draw[button].x, Draw[button].y, Draw[button].radius, Draw.buttons.thickness, Draw.backgrounda, Draw.buttons.border)
		end
	end
	if ty == 1 then -- square
		if Joypad[button_name] then
			Draw.border2(Draw[button].x, Draw[button].y, Draw[button].w, Draw[button].h, Draw.buttons.thickness, Draw[button].color, Draw.buttons.border)
		else
			Draw.border2(Draw[button].x, Draw[button].y, Draw[button].w, Draw[button].h, Draw.buttons.thickness, Draw.backgrounda, Draw.buttons.border)
		end
	end
	wgui.setfont(Draw[button].font_size, Draw[button].font, Draw[button].style)
	wgui.setcolor(Draw.buttons.text_color)
	wgui.drawtext(text, {l = Draw[button].x + Draw[button].x_offset, t = Draw[button].y + Draw[button].y_offset, w = 200, h = 100}, "l")
end

function Draw.cbutton(joypad, offset_mult, angle)
	if Joypad[joypad] then
		Draw.circle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.radius, Draw.buttons.thickness, Draw.cbuttons.color, Draw.buttons.border)
		Draw.triangle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.triangle_size, angle, Draw.cbuttons.triangle_thickness, Draw.cbuttons.color, "black")
	else
		Draw.circle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.radius, Draw.buttons.thickness, Draw.backgrounda, Draw.buttons.border)
		Draw.triangle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.triangle_size, angle, Draw.cbuttons.triangle_thickness, Draw.backgrounda, Draw.buttons.border)
	end
end

function Draw.slot(slot)
	if Slots[slot].var == "holp" then
		style = "%.0f, %.0f, %.0f"
		wgui.drawtext("HOLP", {l = Draw.slots.x, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = Draw.slots.x_offset, h = 100}, "l")
		wgui.drawtext(string.format("%.0f %.0f %.0f", Memory.read("holpx"), Memory.read("holpy"), Memory.read("holpz")), {l = Draw.slots.x + Draw.slots.x_offset, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = 400, h = 100}, "l")
	else
		wgui.drawtext(Memory.addr[Slots[slot].var].name, {l = Draw.slots.x, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = Draw.slots.x_offset, h = 100}, "l")
		local style = nil
		if Memory.addr[Slots[slot].var].float then
			style = "%.3f"
		else
			style = "%d"
		end
		wgui.drawtext(string.format(style, Memory.read(Slots[slot].var)), {l = Draw.slots.x + Draw.slots.x_offset, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = 400, h = 100}, "l")
	end
end

-- Drawing utilities

function Draw.set_text(object)
	wgui.setfont(Draw[object].font_size, Draw[object].font, Draw[object].style)
	wgui.setcolor(Draw[object].text_color)
end

function Draw.calc_stick_points() -- calculates the points for the "stick" polygon
	-- finds the angle the stick makes with the x-axis
	-- adds and subtracts 2 pi to get the perpendicular angles
	local jx = Joypad.X * 75 / 128
	local jy = Joypad.Y * 75 / 128
	local anglep = math.atan2(jy, jx) + (math.pi / 2)
	local anglem = math.atan2(jy, jx) - (math.pi / 2)
	return {{
		round(Draw.cstick.x + (math.cos(anglep) * Draw.cstick.stick.thickness)),
		round(Draw.cstick.y - (math.sin(anglep) * Draw.cstick.stick.thickness))
	},  
	{   
		round(Draw.cstick.x + (math.cos(anglep) * Draw.cstick.stick.thickness) + jx),
		round(Draw.cstick.y - (math.sin(anglep) * Draw.cstick.stick.thickness) - jy)
	},  
	{   
		round(Draw.cstick.x + (math.cos(anglem) * Draw.cstick.stick.thickness) + jx),
		round(Draw.cstick.y - (math.sin(anglem) * Draw.cstick.stick.thickness) - jy)
	},
	{
		round(Draw.cstick.x + (math.cos(anglem) * Draw.cstick.stick.thickness)),
		round(Draw.cstick.y - (math.sin(anglem) * Draw.cstick.stick.thickness))
	}}
end

function Draw.calc_timer() -- converts vi (60 fps) to h:m:s:ms
	local h = vi // 216000
	local m = (vi // 3600) - (h * 60)
	local s = (vi // 60) - (m * 60) - (h * 3600)
	local ms = round((vi * 5 / 3) - (s * 100) - (m * 6000) - (h * 360000))
	return string.format("%02d:%02d:%02d.%02d", h, m, s, ms)
end