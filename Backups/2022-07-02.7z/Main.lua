Slotc = {} -- slot changes
-- Can't do anything before 157, each frame is a table of changes.
-- change format = {action, value} where action is 1 (add) or 2 (remove) and value is the input to that function
-- ex: Slotc[200] = {{1, "hspeed"}, {1, "action"}}

Slotc[4602] = {{1, "hspeed"},{1, "holp"}}

rng = {} -- rng changes

rng[4602] = 48413
rng[207719] = 10

globt = {} -- global timer changes

globt[4602] = 4081
globt[207719] = 105311

otherc = {} -- other changes ex: {{"holpx", 100}, {"holpy", 200}, {"holpz", 300}}



function atinterval()
	-- reset the a press counter if the home button is pressed (only for debugging)
	if ((not prev_input["end"]) and (input.get()["end"])) then
		if drawing then
			Screen.contract()
		else
			Screen.expand()
		end
		drawing = not drawing
	end
	
	if ((not prev_input["home"]) and (input.get()["home"])) then
		print("Resetting A press counter")
		a_presses = 0
	end
	prev_input = input.get()
end

function atvi()
	if Draw.timer.active then -- set vi if the timer is active
		vi = emu.framecount() + 1
	end
	
	local slotdata = Slotc[emu.framecount()]
	if slotdata ~= nil then -- If a slot change for this frame exists then
		for index, value in ipairs(slotdata) do -- for every change in slotdata
			if value[1] == 1 then
				Slots.add(value[2])
				print("added " .. value[2])
			end
			if value[1] == 2 then
				Slots.remove(value[2])
				print("removed " .. value[2])
			end
		end
	end
	
	if set_values then
		local inc_segments = false -- used so the segment counter won't be incremented more than once per frame
		local rngdata = rng[emu.framecount()]
		if rngdata ~= nil then
			Memory.write("rng", rngdata)
			inc_segments = true
		end
		
		local globtdata = globt[emu.framecount()]
		if globtdata ~= nil then
			Memory.write("globaltimer", globtdata)
			inc_segments = true
		end
		
		local otherdata = otherc[emu.framecount()]
		if otherdata ~= nil then
			for index, value in ipairs(otherdata) do
				Memory.write(value[1], value[2])
			end
			inc_segments = true
		end
		
		if inc_segments then
			segments = segments + 1
		end
	end
	
	if drawing then
		Draw.main() -- main draw loop. Very important to keep in vi, not interval, so it syncs up when dumping avi
	end
end

function atinput()
	Joypad = joypad.get(1)
	if Memory.read('action') == 6409 then -- end cutscene action
		Draw.timer.active = false
	end
	if Joypad.A and not prev_Joypad.A then
		a_presses = a_presses + 1
	end
	
	prev_Joypad = Joypad
end

function atstop()
	if drawing then
		Screen.contract()
	end
end

function round(x)
	return math.floor(x + 0.5)
end

PATH = debug.getinfo(1).source:sub(2):match("(.*\\)") -- From InputDirection
dofile (PATH .. "Memory.lua")
dofile (PATH .. "Screen.lua")
dofile (PATH .. "Draw.lua")
dofile (PATH .. "Slots.lua")

vi = 0 -- always equal to emu.framecount() but used because calling emu.framecound() multiple times per frame is slow
a_presses = 0
segments = 1
prev_input = input.get()
Joypad = joypad.get(1)
prev_Joypad = {A = false}
drawing = true
set_values = true

if drawing then
	Screen.expand()
end

Memory.version = Memory.determineVersion()

emu.atinterval(atinterval) -- ran continously
emu.atvi(atvi) -- ran every visual interupt (drawing happens here)
emu.atinput(atinput) -- ran every input frame
emu.atstop(atstop) -- ran when the script is stopped