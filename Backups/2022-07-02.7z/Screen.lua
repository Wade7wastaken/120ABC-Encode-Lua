Screen = {
	init_width = wgui.info().width,
	init_height = wgui.info().height,
	width = 1920,
	height = 1080,
	extra_width = 480
}

function Screen.expand()
	wgui.resize(Screen.width, Screen.height + 24) -- 24 is the width of the bottom display on mupen, differes between systems. Usually 24 on win 11 and 22 on win 10
end

function Screen.contract()
	wgui.resize(Screen.init_width, Screen.init_height)
end