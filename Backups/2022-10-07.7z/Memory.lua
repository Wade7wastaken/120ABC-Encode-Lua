Memory = {
	version = nil,
	addr = {
		action = {
			US = 0x8033B17C,
			JP = 0x80339E0C,
			float = false,
			size = 4,
			name = "Action"
		},
		hspeed = {
			US = 0x8033B1C4,
			JP = 0x80339E54,
			float = true,
			size = 4,
			name = "H Speed"
		},
		xslidespeed = {
			US = 0x8033B1C8,
			JP = 0x80339E58,
			float = true,
			size = 4,
			name = "X Slide Speed"
		},
		zslidespeed = {
			US = 0x8033B1CC,
			JP = 0x80339E5C,
			float = true,
			size = 4,
			name = "Z Slide Speed"
		},
		rng = {
			US = 0x8038EEE0,
			JP = 0x8038EEE0,
			float = false,
			size = 2,
			name = "RNG"
		},
		globaltimer = {
			US = 0x8032D5D4,
			JP = 0x8032C694,
			float = false,
			size = 4,
			name = "RNG"
		},
		holpx = {
			US = 0x8033B3C8,
			JP = 0x8033A058,
			float = true,
			size = 4,
			name = "HOLP X"
		},
		holpy = {
			US = 0x8033B3CC,
			JP = 0x8033A05C,
			float = true,
			size = 4,
			name = "HOLP Y"
		},
		holpz = {
			US = 0x8033B3D0,
			JP = 0x8033A060,
			float = true,
			size = 4,
			name = "HOLP Z"
		},
		angleface = {
			US = 0x8033B19E,
			JP = 0x80339E2E,
			float = false,
			size = 2,
			name = "Angle"
		}
	}
}

function Memory.read(location)
	if Memory.addr[location].float then
		return memory.readfloat(Memory.addr[location][Memory.version])
	else
		return memory.readsize(Memory.addr[location][Memory.version], Memory.addr[location].size)
	end
end

function Memory.write(location, value)
	if Memory.addr[location].float then
		memory.writefloat(Memory.addr[location][Memory.version], value)
	else
		memory.writesize(Memory.addr[location][Memory.version], Memory.addr[location].size, value)
	end
end

function Memory.determineVersion() -- From InputDirection
	if memory.readsize(0x00B22B24, 4) == 1174429700 then -- JP
		return 'JP'
	else -- US
		return 'US'
	end
end