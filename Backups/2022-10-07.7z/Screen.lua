Screen = {
	init_width = wgui.info().width,
	init_height = wgui.info().height,
}

Screen.width = 4 / 3 * Screen.init_width

if Screen.width ~= math.floor(Screen.width) then
	print("Current resolution cannot scale to 16:9.")
	print("Using " .. round(Screen.width) .. " instead of " .. Screen.width)
	Screen.width = round(Screen.width)
end

Screen.height = Screen.init_height - 24
Screen.extra_width = Screen.width - Screen.init_width
Screen.start = Screen.init_width
Screen.middle = Screen.init_width + (Screen.extra_width / 2)

function Screen.expand()
	wgui.resize(Screen.width, Screen.init_height)
end

function Screen.contract()
	wgui.resize(Screen.init_width, Screen.init_height)
end