m = Screen.height / 1080 -- Screen multiplier

Draw = {
	background = "#303030",
	backgrounda = "#303030FF",
	timer = {
		y = round(m * 875),
		active = true,
		font_size = round(m * 70),
		font = "Calibri",
		style = "a",
		color = "#FFFFFF",
		stopped_color = "#AAFFAA"
	},
	cstick = {
		x = Screen.start + round(m * 240), -- 1680
		y = round(m * 795),
		size = round(m * 150),
		circle = {
			thickness = round(m * 2),
			color = "#AAAAAA"
		},
		axis = {
			color = "#AAAAAA"
		},
		border = {
			thickness = round(m * 3),
			color = "#FFFFFFFF"
		},
		stick = {
			thickness = round(m * 3),
			color = "#FFAAAAFF"
		},
		ball = {
			radius = round(m * 5),
			color = "#3333FFFF"
		},
		display = {
			x_offset = round(m * 85),
			y_offset = round(m * -27),
			distance = round(m * 30),
			font_size = round(m * 24),
			font = "Courier New",
			style = "ba",
			text_color = "#FF3333",
		}
	},
	buttons = {
		border = "#FFFFFFFF",
		text_color = "#FFFFFF",
		thickness = round(m * 4)
	},
	a = {
		x = Screen.start + round(m * 310), -- 1750
		y = round(m * 650),
		radius = round(m * 30),
		color = "#FF7777FF",
		font_size = round(m * 32),
		font = "Calibri",
		style = "a",
		x_offset = round(m * -11),
		y_offset = round(m * -27)
	},
	b = {
		x = Screen.start + round(m * 240), -- 1680
		y = round(m * 650),
		radius = round(m * 30),
		color = "#00C000FF",
		font_size = round(m * 32),
		font = "Calibri",
		style = "a",
		x_offset = round(m * -11),
		y_offset = round(m * -27)
	},
	s = {
		x = Screen.start + round(m * 275), -- 1715
		y = round(m * 590),
		radius = round(m * 30),
		color = "#4444FFFF",
		font_size = round(m * 32),
		font = "Calibri",
		style = "a",
		x_offset = round(m * -9),
		y_offset = round(m * -27)
	},
	z = {
		x = Screen.start + round(m * 160), -- 1600
		y = round(m * 630),
		w = round(m * 50),
		h = round(m * 100),
		color = "#888888FF",
		font_size = round(m * 32),
		font = "Calibri",
		style = "a",
		x_offset = round(m * -11),
		y_offset = round(m * -27)
	},
	cbuttons = {
		x = Screen.start + round(m * 180), -- 1620
		y = round(m * 500),
		radius = round(m * 20),
		color = "#00FFFFFF",
		offset = round(m * 40),
		text_color = "#FFFFFF",
		font_size = round(m * 32),
		font = "Calibri",
		style = "a",
		text_offset = {round(m * -12), round(m * -26)},
		triangle_thickness = round(m * 5),
		triangle_size = round(m * 12)
	},
	r = {
		x = Screen.start + round(m * 310), -- 1750
		y = round(m * 500),
		w = round(m * 100),
		h = round(m * 50),
		color = "#888888FF",
		font_size = round(m * 32),
		font = "Calibri",
		style = "a",
		x_offset = round(m * -11),
		y_offset = round(m * -27)
	},
	apress = {
		y = round(m * 50),
		font_size = round(m * 70),
		font = "Calibri",
		style = "a",
		text_color = "#FFFFFF",
		height = round(m * 100),
		offset = round(m * 100)
	},
	slots = {
		x = Screen.start + round(m * 100), -- 1540
		start_y = round(m * 260),
		y_offset = round(m * 40),
		x_offset = round(m * 140),
		font_size = round(m * 24),
		font = "Calibri",
		style = "a",
		text_color = "#FFFFFF",
	},
	author = {
		author = "",
		y = round(m * 985),
		font_size = round(m * 24),
		font = "Calibri",
		style = "a",
		text_color = "#FFFFFF"
	}
}

function Draw.main()
	-- Clear the screen
	wgui.fillrecta(Screen.start, 0, Screen.extra_width, Screen.height, Draw.backgrounda)
	-- Draw timer
	wgui.setfont(Draw.timer.font_size, Draw.timer.font, Draw.timer.style)
	if Draw.timer.active then
		wgui.setcolor(Draw.timer.color)
	else
		wgui.setcolor(Draw.timer.stopped_color)
	end
	wgui.drawtext(Draw.calc_timer(), {l = Screen.init_width, t = Draw.timer.y, w = Screen.extra_width, h = 100}, "c")
	-- Draw c stick
	Draw.circle(Draw.cstick.x, Draw.cstick.y, Draw.cstick.size / 2, Draw.cstick.circle.thickness, Draw.background, Draw.cstick.circle.color)
	-- Draw axes
	wgui.setpen(Draw.cstick.axis.color)
	wgui.line(Draw.cstick.x - (Draw.cstick.size / 2), Draw.cstick.y, Draw.cstick.x + (Draw.cstick.size / 2), Draw.cstick.y)
	wgui.line(Draw.cstick.x, Draw.cstick.y - (Draw.cstick.size / 2), Draw.cstick.x, Draw.cstick.y + (Draw.cstick.size / 2))
	-- Draw border
	Draw.border(Draw.cstick.x, Draw.cstick.y, Draw.cstick.size, Draw.cstick.size, Draw.cstick.border.thickness, Draw.cstick.border.color)
	-- Draw stick
	wgui.fillpolygona(Draw.calc_stick_points(), Draw.cstick.stick.color)
	Draw.fillcircle(Draw.cstick.x, Draw.cstick.y, Draw.cstick.stick.thickness, Draw.cstick.stick.color)
	-- Draw ball
	Draw.fillcircle(Draw.cstick.x + (Joypad.X * round(Draw.cstick.size / 2) / 128), Draw.cstick.y - (Joypad.Y * round(Draw.cstick.size / 2) / 128), Draw.cstick.ball.radius, Draw.cstick.ball.color)
	-- Draw c stick display
	wgui.setfont(Draw.cstick.display.font_size, Draw.cstick.display.font, Draw.cstick.display.style)
	wgui.setcolor(Draw.cstick.display.text_color)
	wgui.drawtext(string.format("X: %d", Joypad.X), {l = Draw.cstick.x + Draw.cstick.display.x_offset, t = Draw.cstick.y + Draw.cstick.display.y_offset, w = 200, h = 30}, "l")
	wgui.drawtext(string.format("Y: %d", Joypad.Y), {l = Draw.cstick.x + Draw.cstick.display.x_offset, t = Draw.cstick.y + Draw.cstick.display.y_offset + Draw.cstick.display.distance, w = 200, h = 30}, "l")
	-- Draw buttons
	Draw.button("a", "A", "A", 0) -- table name, joypad name, text, type
	Draw.button("b", "B", "B", 0)
	Draw.button("s", "start", "S", 0)
	Draw.button("z", "Z", "Z", 1)
	Draw.button("r", "R", "R", 1)
	-- Draw c buttons
	Draw.set_text("cbuttons")
	wgui.drawtext("C", {l = Draw.cbuttons.x + Draw.cbuttons.text_offset[1], t = Draw.cbuttons.y + Draw.cbuttons.text_offset[2], w = 200, h = 100}, "l")
	Draw.cbutton("Cup", {0, -1}, 0) -- joypad name, table with multipliers for the x and y offsets, angle
	Draw.cbutton("Cright", {1, 0}, -math.pi / 2) -- table example: {0, 0} means no offset, {1, 0} means x offset, {0, -1} means negative y offset
	Draw.cbutton("Cdown", {0, 1}, math.pi)
	Draw.cbutton("Cleft", {-1, 0}, math.pi / 2)
	-- Draw a press counter
	Draw.set_text("apress")
	wgui.drawtext("A Presses:", {l = Screen.init_width, t = Draw.apress.y, w = Screen.extra_width, h = 100}, "c")
	wgui.drawtext(string.format("%d", a_presses), {l = Screen.init_width, t = Draw.apress.y + Draw.apress.offset, w = Screen.extra_width, h = 100}, "c")
	-- Draw variable slots and segment counter
	Draw.set_text("slots")
	wgui.drawtext("Segment", {l = Draw.slots.x, t = Draw.slots.start_y, w = Draw.slots.x_offset, h = 100}, "l")
	wgui.drawtext(string.format("%d", segments), {l = Draw.slots.x + Draw.slots.x_offset, t = Draw.slots.start_y, w = 400, h = 100}, "l")
	for i = 1, 3, 1 do
		if Slots[i].occupied then
			Draw.slot(i)
		end
	end
	Draw.set_text("author")
	wgui.drawtext("Author: " .. Draw.author.author, {l = Screen.init_width, t = Draw.author.y, w = Screen.extra_width, h = 100}, "c")
	if draw_pictures then
		--Image.draw(100, 100, 'discord')
		--Image.draw2(mario)
	end
end

-- Shape drawing functions

function Draw.border(x, y, w, h, b, color) -- Draws a border using 4 rectangles (doesn't overwrite middle)
	wgui.fillrecta(x - (w / 2), y - (h / 2), b, h, color)
	wgui.fillrecta(x - (w / 2) + b, y + (h / 2) - b, w - (b * 2), b, color)
	wgui.fillrecta(x + (w / 2) - b, y - (h / 2), b, h, color)
	wgui.fillrecta(x - (w / 2) + b, y - (h / 2), w - (b * 2), b, color)
end

function Draw.border2(x, y, w, h, thickness, inner_color, border_color) -- Draws a border using 2 overlapping rectangles (overwrites middle)
	wgui.fillrecta(x - (w / 2), y - (h / 2), w, h, border_color)
	wgui.fillrecta(x - (w / 2) + thickness, y - (h / 2) + thickness, w - (thickness * 2), h - (thickness * 2), inner_color)
end

function Draw.circle(x, y, r, thickness, inner_color, border_color) -- Draws a circle border (overwrites middle)
	wgui.fillellipsea(x - r, y - r, r * 2, r * 2, border_color)
	wgui.fillellipsea(x - (r - thickness), y - (r - thickness), (r - thickness) * 2, (r - thickness) * 2, inner_color)
end

function Draw.fillcircle(x, y, r, color) -- Draws a filled in circle
	wgui.fillellipsea(x - r, y - r, r * 2, r * 2, color)
end

function Draw.triangle(x, y, length, angle, thickness, inner_color, border_color)
	wgui.fillpolygona({{
		round(x + (math.cos((math.pi / 2) + angle) * length)),
		round(y - (math.sin((math.pi / 2) + angle) * length))
	}, {
		round(x + (math.cos((7 / 6 * math.pi) + angle) * length)),
		round(y - (math.sin((7 / 6 * math.pi) + angle) * length))
	}, {
		round(x + (math.cos((11 / 6 * math.pi) + angle) * length)),
		round(y - (math.sin((11 / 6 * math.pi) + angle) * length))
	}}, border_color)
	wgui.fillpolygona({{
		round(x + (math.cos((math.pi / 2) + angle) * (length - thickness))),
		round(y - (math.sin((math.pi / 2) + angle) * (length - thickness)))
	}, {
		round(x + (math.cos((7 / 6 * math.pi) + angle) * (length - thickness))),
		round(y - (math.sin((7 / 6 * math.pi) + angle) * (length - thickness)))
	}, {
		round(x + (math.cos((11 / 6 * math.pi) + angle) * (length - thickness))),
		round(y - (math.sin((11 / 6 * math.pi) + angle) * (length - thickness)))
	}}, inner_color)
end

-- Complex drawing functions

function Draw.button(button, button_name, text, ty) -- Draws a circular button and text
	if ty == 0 then -- circle
		if Joypad[button_name] then
			Draw.circle(Draw[button].x, Draw[button].y, Draw[button].radius, Draw.buttons.thickness, Draw[button].color, Draw.buttons.border)
		else
			Draw.circle(Draw[button].x, Draw[button].y, Draw[button].radius, Draw.buttons.thickness, Draw.backgrounda, Draw.buttons.border)
		end
	end
	if ty == 1 then -- square
		if Joypad[button_name] then
			Draw.border2(Draw[button].x, Draw[button].y, Draw[button].w, Draw[button].h, Draw.buttons.thickness, Draw[button].color, Draw.buttons.border)
		else
			Draw.border2(Draw[button].x, Draw[button].y, Draw[button].w, Draw[button].h, Draw.buttons.thickness, Draw.backgrounda, Draw.buttons.border)
		end
	end
	wgui.setfont(Draw[button].font_size, Draw[button].font, Draw[button].style)
	wgui.setcolor(Draw.buttons.text_color)
	wgui.drawtext(text, {l = Draw[button].x + Draw[button].x_offset, t = Draw[button].y + Draw[button].y_offset, w = 200, h = 100}, "l")
end

function Draw.cbutton(joypad, offset_mult, angle)
	if Joypad[joypad] then
		Draw.circle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.radius, Draw.buttons.thickness, Draw.cbuttons.color, Draw.buttons.border)
		Draw.triangle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.triangle_size, angle, Draw.cbuttons.triangle_thickness, Draw.cbuttons.color, "black")
	else
		Draw.circle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.radius, Draw.buttons.thickness, Draw.backgrounda, Draw.buttons.border)
		Draw.triangle(Draw.cbuttons.x + (Draw.cbuttons.offset * offset_mult[1]), Draw.cbuttons.y + (Draw.cbuttons.offset * offset_mult[2]), Draw.cbuttons.triangle_size, angle, Draw.cbuttons.triangle_thickness, Draw.backgrounda, Draw.buttons.border)
	end
end

function Draw.slot(slot)
	if Slots[slot].var == "holp" then
		style = "%.0f, %.0f, %.0f"
		wgui.drawtext("HOLP", {l = Draw.slots.x, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = Draw.slots.x_offset, h = 100}, "l")
		wgui.drawtext(string.format("%.0f %.0f %.0f", Memory.read("holpx"), Memory.read("holpy"), Memory.read("holpz")), {l = Draw.slots.x + Draw.slots.x_offset, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = 400, h = 100}, "l")
	else
		wgui.drawtext(Memory.addr[Slots[slot].var].name, {l = Draw.slots.x, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = Draw.slots.x_offset, h = 100}, "l")
		local style = nil
		if Memory.addr[Slots[slot].var].float then
			style = "%.3f"
		else
			style = "%d"
		end
		wgui.drawtext(string.format(style, Memory.read(Slots[slot].var)), {l = Draw.slots.x + Draw.slots.x_offset, t = Draw.slots.start_y + (slot * Draw.slots.y_offset), w = 400, h = 100}, "l")
	end
end

-- Drawing utilities

function Draw.set_text(object)
	wgui.setfont(Draw[object].font_size, Draw[object].font, Draw[object].style)
	wgui.setcolor(Draw[object].text_color)
end

function Draw.calc_stick_points() -- calculates the points for the "stick" polygon
	-- finds the angle the stick makes with the x-axis
	-- adds and subtracts 2 pi to get the perpendicular angles
	local jx = Joypad.X * round(Draw.cstick.size / 2) / 128
	local jy = Joypad.Y * round(Draw.cstick.size / 2) / 128
	local anglep = math.atan2(jy, jx) + (math.pi / 2)
	local anglem = math.atan2(jy, jx) - (math.pi / 2)
	return {{
		round(Draw.cstick.x + (math.cos(anglep) * Draw.cstick.stick.thickness)),
		round(Draw.cstick.y - (math.sin(anglep) * Draw.cstick.stick.thickness))
	},  
	{   
		round(Draw.cstick.x + (math.cos(anglep) * Draw.cstick.stick.thickness) + jx),
		round(Draw.cstick.y - (math.sin(anglep) * Draw.cstick.stick.thickness) - jy)
	},  
	{   
		round(Draw.cstick.x + (math.cos(anglem) * Draw.cstick.stick.thickness) + jx),
		round(Draw.cstick.y - (math.sin(anglem) * Draw.cstick.stick.thickness) - jy)
	},
	{
		round(Draw.cstick.x + (math.cos(anglem) * Draw.cstick.stick.thickness)),
		round(Draw.cstick.y - (math.sin(anglem) * Draw.cstick.stick.thickness))
	}}
end

function Draw.calc_timer() -- converts vi (60 fps) to h:m:s:ms
	local h = vi // 216000
	local m = (vi // 3600) - (h * 60)
	local s = (vi // 60) - (m * 60) - (h * 3600)
	local ms = round((vi * 5 / 3) - (s * 100) - (m * 6000) - (h * 360000))
	return string.format("%02d:%02d:%02d.%02d", h, m, s, ms)
end