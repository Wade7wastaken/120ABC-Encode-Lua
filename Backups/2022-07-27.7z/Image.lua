Image = {
	
}

function Image.init()
	Image.load('discord')
end

function Image.load(name)
	print("Loading " .. "images\\" .. name .. ".txt")
	local file = io.open(PATH .. "images\\" .. name .. ".txt", "rb")
	if not file then
		print("Couldn\'t find file")
		return nil
	end
	
	local numbers = {}
	local cur_number = ""
	local cur_char = ""
	while true do
		cur_char = file:read(1)
		if cur_char == "," then
			table.insert(numbers, cur_number)
			cur_number = ""
		else
			cur_number = cur_number .. cur_char
		end
		cur_char = ""
		if file:read(0) == nil then
			table.insert(numbers, cur_number)
			break
		end
	end
	
	file:close()
	Image[name] = numbers
	print("Finished loading")
end

function Image.draw(xi, yi, name)
	--print('Drawing ' .. name)
	local data = Image[name]
	local w = data[1]
	local h = data[2]
	
	for y = 100, h - 1, 1 do
		for x = 100, w - 1, 1 do
			wgui.fillrecta(xi + x, yi + y, 1, 1, "#" .. data[(3 * (y * w + x)) + 3] .. data[(3 * (y * w + x)) + 4] .. data[(3 * (y * w + x)) + 5] .. "FF")
		end
	end
end

function Image.draw2(tab)
	w = tab[2]
	h = tab[3]
	polygons = tab[1]
	for index, value in ipairs(polygons) do -- loop over polygons
		wgui.fillpolygona(value[1], value[2])
	end
end